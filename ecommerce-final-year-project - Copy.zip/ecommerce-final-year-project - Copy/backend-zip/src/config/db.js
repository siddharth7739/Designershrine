const mongoose = require("mongoose")

const mongoDbUrl='mongodb+srv://sumitqu:PmAbtHvSpT59ILSI@cluster0.wltkqfb.mongodb.net/EcomDb?retryWrites=true&w=majority&appName=Cluster0'
// const mongoDbUrl='mongodb+srv://sumitqu:j6QQVK6eC4mgBjV5@cluster0.sj7g8kd.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0/'

const connectDb=()=>{
    return mongoose.connect(mongoDbUrl)
}

module.exports={connectDb}