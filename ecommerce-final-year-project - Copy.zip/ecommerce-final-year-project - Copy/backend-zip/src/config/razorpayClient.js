const Razorpay = require('razorpay');

apiKey = "rzp_test_yYtg5mOAeyTGkH";
apiSecret = "eJ29BcCc6yHqxOc2iHVFP5Re";

const razorpay = new Razorpay({
  key_id: apiKey,
  key_secret: apiSecret,
});

module.exports = razorpay