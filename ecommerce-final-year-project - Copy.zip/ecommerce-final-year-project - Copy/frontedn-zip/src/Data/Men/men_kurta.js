export const mens_kurta=[
    {
        "imageUrl": "https://rukminim2.flixcart.com/image/832/832/xif0q/ethnic-set/g/z/m/l-na-cposk612-310-manyavar-original-imagz4nzfp3quhjy.jpeg?q=70&crop=false",
        "brand": "Kurta",
        "title": "More On Men's Kurta...",
        "nav": "men/clothing/mens_kurta",
        "color": "Green",
        "discountedPrice": 499,
        "price": 1499,
        "discountPersent": 66,
        "size": [
            {
              "name": "S",
              "quantity": 20
            },
            {
              "name": "M",
              "quantity": 30
            },
            {
              "name": "L",
              "quantity": 50
            }
          ],
          "quantity": 100,
          "topLavelCategory": "Men",
          "secondLavelCategory": "Clothing",
          "thirdLavelCategory": "mens_kurta",
          "description":"A traditional garment embodying elegance and grace. Crafted from fine fabrics, it features intricate embroidery and a relaxed fit, providing comfort and style."
    },
    {
        "imageUrl": "https://rukminim2.flixcart.com/image/832/832/xif0q/shirt/o/j/k/36-lslm1228v1na22fn-blackberrys-original-imagm8f2zjxkf3h7.jpeg?q=70&crop=false",
        "brand": "Shirts",
        "title": "More On Men's Shrits...",
        "nav": "men/clothing/shirt",
        "color": "Yellow",
        "discountedPrice": 799,
        "price": 2499,
        "discountPersent": 68,
        "size": [
            {
              "name": "S",
              "quantity": 20
            },
            {
              "name": "M",
              "quantity": 30
            },
            {
              "name": "L",
              "quantity": 50
            }
          ],
          "quantity": 100,
          "topLavelCategory": "Men",
          "secondLavelCategory": "Clothing",
          "thirdLavelCategory": "mens_kurta",
          "description":"A traditional garment embodying elegance and grace. Crafted from fine fabrics, it features intricate embroidery and a relaxed fit, providing comfort and style."
    },
    {
        "imageUrl": "https://rukminim2.flixcart.com/image/832/832/xif0q/jean/n/m/1/31-244508401-jack-jones-original-imagxzh2drfgnrtu.jpeg?q=70&crop=false",
        "brand": "Jeans",
        "title": "More On Men's Jeans...",
        "nav": "men/clothing/men_jeans",
        "color": "Blue",
        "discountedPrice": 399,
        "price": 1499,
        "discountPersent": 73,
        "size": [
            {
              "name": "S",
              "quantity": 20
            },
            {
              "name": "M",
              "quantity": 30
            },
            {
              "name": "L",
              "quantity": 50
            }
          ],
          "quantity": 100,
          "topLavelCategory": "Men",
          "secondLavelCategory": "Clothing",
          "thirdLavelCategory": "mens_kurta",
          "description":"A traditional garment embodying elegance and grace. Crafted from fine fabrics, it features intricate embroidery and a relaxed fit, providing comfort and style."
    },
    {
        "imageUrl": "https://rukminim2.flixcart.com/image/832/832/xif0q/sweater/j/u/u/-original-imaggbyah9c4vykh.jpeg?q=70&crop=false",
        "brand": "Sweatres",
        "title": "More On Men's Sweatres...",
        "nav": "men/clothing/sweatres",
        "color": "White",
        "discountedPrice": 474,
        "price": 1999,
        "discountPersent": 76,
        "size": [
            {
              "name": "S",
              "quantity": 20
            },
            {
              "name": "M",
              "quantity": 30
            },
            {
              "name": "L",
              "quantity": 50
            }
          ],
          "quantity": 100,
          "topLavelCategory": "Men",
          "secondLavelCategory": "Clothing",
          "thirdLavelCategory": "mens_kurta",
          "description":"A traditional garment embodying elegance and grace. Crafted from fine fabrics, it features intricate embroidery and a relaxed fit, providing comfort and style."
    },
    {
        "imageUrl": "https://rukminim2.flixcart.com/image/832/832/xif0q/t-shirt/x/f/m/xl-bhtssk22072-cactus-green-being-human-original-imagsqexs2sgcczh.jpeg?q=70&crop=false",
        "brand": "T-Shirt",
        "title": "More On Men's T-Shirts...",
        "nav": "men/clothing/tshirts",
        "color": "Grey",
        "discountedPrice": 524,
        "price": 1049,
        "discountPersent": 50,
        "size": [
            {
              "name": "S",
              "quantity": 20
            },
            {
              "name": "M",
              "quantity": 30
            },
            {
              "name": "L",
              "quantity": 50
            }
          ],
          "quantity": 100,
          "topLavelCategory": "Men",
          "secondLavelCategory": "Clothing",
          "thirdLavelCategory": "mens_kurta",
          "description":"A traditional garment embodying elegance and grace. Crafted from fine fabrics, it features intricate embroidery and a relaxed fit, providing comfort and style."
    },
    {
        "imageUrl": "https://rukminim2.flixcart.com/image/832/832/xif0q/jacket/o/w/e/xxl-no-247242401-jack-jones-original-imagtq5hzz3mqhzr.jpeg?q=70&crop=false",
        "brand": "Jacket",
        "title": "More On Men's Jackets...",
        "nav": "men/clothing/jackets",
        "color": "Pink",
        "discountedPrice": 499,
        "price": 1499,
        "discountPersent": 66,
        "size": [
            {
              "name": "S",
              "quantity": 20
            },
            {
              "name": "M",
              "quantity": 30
            },
            {
              "name": "L",
              "quantity": 50
            }
          ],
          "quantity": 100,
          "topLavelCategory": "Men",
          "secondLavelCategory": "Clothing",
          "thirdLavelCategory": "mens_kurta",
          "description":"A traditional garment embodying elegance and grace. Crafted from fine fabrics, it features intricate embroidery and a relaxed fit, providing comfort and style."
    },
    {
      "imageUrl": "https://rukminim2.flixcart.com/image/832/832/xif0q/track-suit/w/4/f/l-fl14-1-nivia-original-imagw6yjygfsubys.jpeg?q=70&crop=false",
      "brand": "Active Wear",
      "title": "More On Men's Active Wear...",
      "nav": "men/clothing/activewear",
      "color": "Pink",
      "discountedPrice": 499,
      "price": 1499,
      "discountPersent": 66,
      "size": [
          {
            "name": "S",
            "quantity": 20
          },
          {
            "name": "M",
            "quantity": 30
          },
          {
            "name": "L",
            "quantity": 50
          }
        ],
        "quantity": 100,
        "topLavelCategory": "Men",
        "secondLavelCategory": "Clothing",
        "thirdLavelCategory": "mens_kurta",
        "description":"A traditional garment embodying elegance and grace. Crafted from fine fabrics, it features intricate embroidery and a relaxed fit, providing comfort and style."
  }
]