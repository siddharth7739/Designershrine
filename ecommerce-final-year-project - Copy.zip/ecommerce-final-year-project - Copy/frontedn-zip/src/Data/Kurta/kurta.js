export const kurtaPage1=[
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/xif0q/top/3/v/t/xl-192602302-vero-moda-original-imagxvvddftazyhe.jpeg?q=70&crop=false",
        "brand": "Top",
        "title": "More On Women's Tops...",
        "nav": "women/clothing/top",
        "color": "red",
        "selling_price": "₹699",
        "price": "₹2,899",
        "disscount": "75% off",
        "size": ""
    },
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/kpk3csw0/dress/k/o/t/m-darshn-red-81-aryadressmaker-original-imag3rcbwugazmpa.jpeg?q=70&crop=false",
        "brand": "Dresses",
        "title": "More On Women's Dresses...",
        "nav": "women/clothing/dresses",
        "color": "black",
        "selling_price": "₹1,082",
        "price": "₹2,799",
        "disscount": "61% off",
        "size": ""
    },
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/xif0q/jean/n/y/x/32-j2210351by-calvin-klein-jeans-original-imagn3f2hq2qz9gp.jpeg?q=70&crop=false",
        "brand": "Jeans",
        "title": "More On Women's Jeans..",
        "nav": "women/clothing/jeans",
        "color": "",
        "selling_price": "₹702",
        "price": "₹3,997",
        "disscount": "82% off",
        "size": ""
    },
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/xif0q/lehenga-choli/c/5/d/free-na-chd-ugceml50344b-soch-original-imagvp4y5yb8fvfe.jpeg?q=70&crop=false",
        "brand": "Lehenga Choli",
        "title": "More On Lehenga Choli...",
        "nav": "women/clothing/lehengacholi",
        "color": "",
        "selling_price": "₹664",
        "price": "₹2,999",
        "disscount": "77% off",
        "size": ""
    },
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/xif0q/sari/p/s/w/free-3395s225-samah-unstitched-original-imagwtjwg4gf8f4j.jpeg?q=70&crop=false",
        "brand": "Sarees",
        "title": "More On Sarees...",
        "nav": "women/clothing/sarees",
        "color": "",
        "selling_price": "₹433",
        "price": "₹2,995",
        "disscount": "85% off",
        "size": ""
    },
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/xif0q/gown/r/m/t/na-m-3-4-sleeve-stitched-ows3cd2012a-soch-na-original-imagpqnrmwuydugu.jpeg?q=70&crop=false",
        "brand": "Gouns",
        "title": "More On Gouns...",
        "nav": "women/clothing/gouns",
        "color": "",
        "selling_price": "₹779",
        "price": "₹1,299",
        "disscount": "40% off",
        "size": ""
    },
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/xif0q/t-shirt/i/s/a/l-j20j221013pe5-calvin-klein-jeans-original-imagn3cbbgpv5anw.jpeg?q=70&crop=false",
        "brand": "T-shirts",
        "title": "More On Women's T-shirts...",
        "nav": "women/clothing/t-shirts",
        "color": "",
        "selling_price": "₹748",
        "price": "₹1,999",
        "disscount": "62% off",
        "size": ""
    }
]