export const mensShoesPage1=[
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/xif0q/watch/u/a/f/1-dtwgc2019004-set-c-ducati-corse-men-original-imagxe339qgzjzgt.jpeg?q=70&crop=false",
        "brand": "Mens's Watches",
        "title": "More On Men's Watches...",
        "nav": "men/accessories/watch",
    },
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/xif0q/watch/j/6/t/-original-imagsykv7n5dznjk.jpeg?q=70&crop=false",
        "brand": "Women's Watches",
        "title": "More On women's Watches...",
        "nav": "women/accessories/watch",
    },
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/xif0q/wallet-card-wallet/d/f/z/wallet-1-120-hrbrfrfd-04-2-wallet-hh-trader-95-original-imagwhedu7veghyw.jpeg?q=70&crop=false",
        "brand": "Men's Wallet",
        "title": "More On Men's Wallets...",
        "nav": "men/accessories/wallets",
    },
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/xif0q/sunglass/i/1/d/d5t-6yyi-hayden-haiza-original-imagvzb8s2hdapuy.jpeg?q=70&crop=false",
        "brand": "Women's Sunglasses",
        "title": "More On Women's Sunglasses...",
        "nav": "women/accessories/sunglasses",
    },
    {
        "image": "https://rukminim2.flixcart.com/image/416/416/xif0q/hat/4/q/8/pn-ht-002-free-1-women-hat-pn-ht-002-the-bling-stores-original-imaggf7z3kkqk5xe.jpeg?q=70&crop=false",
        "brand": "Women's Hat",
        "title": "More On Women's Hats...",
        "nav": "women/accessories/hats",
    },
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/xif0q/hand-messenger-bag/q/t/h/-original-imagu6ykk6gna29q.jpeg?q=70&crop=false",
        "brand": "Women's Purses",
        "title": "More On Women's Purses...",
        "nav": "women/accessories/purses",
    },
    {
        "image": "https://rukminim2.flixcart.com/image/832/832/xif0q/sunglass/4/k/y/large-ids2914c3sg-idee-original-imagxx3yyd8yvz5g.jpeg?q=70&crop=false",
        "brand": "Men's Sunglasses",
        "title": "More On Men's Sunglasses...",
        "nav": "men/accessories/sunglasses",
    }
]