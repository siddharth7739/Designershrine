import { Button, Grid, Typography } from '@mui/material'
import React from 'react'

const Footer = () => {
  return (
    <div>
        <Grid className='bg-beige text-#414A4C text-center mt-10'
        container
        sx ={{backgroundImage: 'linear-gradient(to top, white, #D8BAB1)',
        color:'#414A4C', py:3}}>
            <Grid item xs={12} sm={6} md={3}>
                <Typography className='pb-5' color={'black'} variant='h6'>DESIGNER SHRINE</Typography>
                <div>
                <Button className='pb-5' variant='h6' gutterBottom>About</Button>
                </div>
                <div>
                <Button className='pb-5' variant='h6' gutterBottom>Partners</Button>
                </div>
                <div>
                <Button className='pb-5' variant='h6' gutterBottom>Contact us</Button>
                </div>
                <div>
                <Button className='pb-5' variant='h6' gutterBottom>Know more</Button>
                </div> 
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
                <Typography className='pb-5' color={'black'} variant='h6'>CUSTOMER POLICIES</Typography>
                <div>
                <Button className='pb-5' variant='h6' gutterBottom>FAQ</Button>
                </div>
                <div>
                <Button className='pb-5' variant='h6' gutterBottom>T&C</Button>
                </div>
                <div>
                <Button className='pb-5' variant='h6' gutterBottom>Return policy</Button>
                </div>
                <div>
                <Button className='pb-5' variant='h6' gutterBottom>Privacy policy</Button>
                </div> 
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
                <Typography className='pb-5' color={'black'} variant='h6'>IMPORTANT LINKS</Typography>
                <div>
                <Button className='pb-5' variant='h6' gutterBottom>Blog</Button>
                </div>
                <div>
                <Button className='pb-5' variant='h6' gutterBottom>Carrers</Button>
                </div>
                <div>
                <Button className='pb-5' variant='h6' gutterBottom>Cancellation policy</Button>
                </div>
                <div>
                <Button className='pb-5' variant='h6' gutterBottom>Partners</Button>
                </div> 
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
                <Typography className='pb-5' color={'black'} variant='h6'>SOCIALS</Typography>
                <div>
                <Button className='pb-5' variant='h6' gutterBottom>FACKBOOK</Button>
                </div>
                <div>
                <Button className='pb-5' variant='h6' gutterBottom>INSTAGRAM</Button>
                </div>
                <div>
                <Button className='pb-5' variant='h6' gutterBottom>TWITTER</Button>
                </div>
                <div>
                <Button className='pb-5' variant='h6' gutterBottom>REDDIT</Button>
                </div> 
            </Grid>
            <Grid className='pt-20' item xs = {12}>
              <Typography variant='body2' color={'grey'} component = "p" allign = "center">
              &copy; 2023 www.DesignersShrine.com. All Rights Reserved.
              </Typography>
              <Typography variant='body2' color={'grey'} component = "p" allign = "center">
              Made With Love By -
              <div>
              Srija | Sumit | Siddharth | Sanobar
              </div>
              </Typography>
            </Grid>
        </Grid>
    </div>
  )
}

export default Footer